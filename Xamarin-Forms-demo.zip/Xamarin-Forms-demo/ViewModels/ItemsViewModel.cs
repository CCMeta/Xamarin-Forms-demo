﻿using Microsoft.Extensions.Logging;
using Serilog;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Net.Http;
using System.Net.WebSockets;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin_Forms_demo.Models;
using Xamarin_Forms_demo.Views;
using SIPSorcery.Net;

namespace Xamarin_Forms_demo.ViewModels
{
    public class ItemsViewModel : BaseViewModel
    {
        public ObservableCollection<Item> Items { get; set; }
        public Command LoadItemsCommand { get; set; }

        public static ClientWebSocket ClientWebSocket { get; set; }
        public static ArraySegment<byte> response_buffer;
        public static StringDictionary rtc_session = new StringDictionary();
        public static RTCPeerConnection fuck_peer;

        public ItemsViewModel()
        {
            Title = "Browse";
            Items = new ObservableCollection<Item>();
            LoadItemsCommand = new Command(async () => await ExecuteLoadItemsCommand());
            MessagingCenter.Subscribe<NewItemPage, Item>(this, "AddItem", async (obj, item) =>
            {
                var newItem = item as Item;
                Items.Add(newItem);
                await DataStore.AddItemAsync(newItem);

            });
            AddConsoleLogger();
            FuckServerWebSocket();
            FuckServerWebRTCAsync();
        }
        
        async void FuckServerWebSocket()
        {
            ClientWebSocket = new ClientWebSocket();
            var uri = new Uri("wss://zaiwuhou.com:9502/websocket");
            response_buffer = WebSocket.CreateClientBuffer(4096 * 20, 4096 * 20);
            await ClientWebSocket.ConnectAsync(uri, CancellationToken.None);
            //await ClientWebSocket.SendAsync(new ArraySegment<byte>(System.Text.Encoding.ASCII.GetBytes("badmother")), WebSocketMessageType.Binary, true, CancellationToken.None);
            //Fuck(response_buffer);
            while (true)
            {
                WebSocketReceiveResult response = await ClientWebSocket.ReceiveAsync(response_buffer, CancellationToken.None);
                if (response.EndOfMessage)
                {
                    var fucksegment = response_buffer.Array;
                    Array.Resize(ref fucksegment, response.Count);
                    var response_string = System.Text.Encoding.UTF8.GetString(fucksegment);
                    var response_json = JsonSerializer.Deserialize<Hashtable>(response_string);
                    var action_type = response_json["type"].ToString();
                    var action_data = response_json["data"].ToString();
                    switch (action_type)
                    {
                        case "set-sid":
                            Fuck("Switch to set-sid");
                            rtc_session.Add("sid", action_data);
                            break;
                        case "description":
                            Fuck("Switch to description");
                            //break;
                            var response_data_Hashtable = JsonSerializer.Deserialize<Hashtable>(action_data);
                            switch (response_data_Hashtable["type"].ToString())
                            {
                                case "offer":
                                    //setremote
                                    var init = new RTCSessionDescriptionInit()
                                    {
                                        sdp = response_data_Hashtable["sdp"].ToString(),
                                        type = RTCSdpType.offer,
                                    };
                                    for (int i = 0; i < 50; i++)
                                    {
                                    }
                                    fuck_peer.setRemoteDescription(init);

                                    //setLocalDescription
                                    var answer = fuck_peer.createAnswer(new RTCAnswerOptions());
                                    await fuck_peer.setLocalDescription(answer);

                                    //send answer to offerman
                                    string request_json = JsonSerializer.Serialize(new
                                    {
                                        type = "description",
                                        data = new { type = answer.type.ToString(), answer.sdp },
                                    });
                                    await ClientWebSocket.SendAsync(
                                        new ArraySegment<byte>(System.Text.Encoding.ASCII.GetBytes(request_json)),
                                        WebSocketMessageType.Binary, true, CancellationToken.None);
                                    break;
                                case "answer":
                                    fuck_peer.SetRemoteDescription(
                                        SIPSorcery.SIP.App.SdpType.answer,
                                        SDP.ParseSDPDescription(response_data_Hashtable["sdp"].ToString()));
                                    break;
                                default:
                                    Fuck("switch2 enter in default fucked");
                                    break;
                            }
                            break;
                        case "ice-candidate":
                            Fuck("Switch to ice-candidate");
                            //be careful with empty action_data
                            var _RTCIceCandidateInit = JsonSerializer.Deserialize<RTCIceCandidateInit>(action_data);

                            fuck_peer.addIceCandidate(_RTCIceCandidateInit);

                            //RTCIceCandidate
                            //local's candidate is no need to call addicecandidate
                            //addIceCandidate.candidate = action_data;//就他妈觉得这里有毛病



                            Fuck("connectionState = " + fuck_peer.connectionState);//new
                            Fuck("iceConnectionState = " + fuck_peer.iceConnectionState);//checking
                            Fuck("iceGatheringState = " + fuck_peer.iceGatheringState);//new
                            Fuck("signalingState = " + fuck_peer.signalingState);//have_local_offer
                            break;
                        default:
                            Fuck($"Switch to in default fucked----{response_string}");
                            break;
                    } //end of switch
                }//end of if
            }//end of while loop
        }
        
        async void FuckServerWebRTCAsync()
        {
            
            Fuck("Get Started WebRTC");
            var ssl_file = await new HttpClient().GetAsync("https://doudousong.com/ssl.");
            //Fuck(await ssl_file.Content.ReadAsByteArrayAsync());
            //var path = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var localhostCert = new X509Certificate2(await ssl_file.Content.ReadAsByteArrayAsync(), "0");
            var presetCertificates = new List<RTCCertificate> {
                new RTCCertificate { Certificate = localhostCert },
            };
            var IceServersStun = new RTCIceServer
            {
                urls = "stuns:103.93.252.155:3478",
            };
            var IceServersTurn = new RTCIceServer
            {
                urls = "turn:103.93.252.155:3478",
                username = "username1",
                credential = "key1",
            };
            var presetIceServers = new List<RTCIceServer> { IceServersStun, IceServersTurn };
            var RTCConfiguration = new RTCConfiguration
            {
                certificates = presetCertificates,
                iceServers = presetIceServers,
            };
            fuck_peer = new RTCPeerConnection(RTCConfiguration);


            fuck_peer.OnReceiveReport += (IPEndPoint, SDPMediaTypesEnum, RTPPacket) =>
            {
                Console.WriteLine("OnReceiveReport IPEndPoint=====" + IPEndPoint);
                Console.WriteLine("OnReceiveReport SDPMediaTypesEnum=====" + SDPMediaTypesEnum);
                Console.WriteLine("OnReceiveReport RTPPacket=====" + RTPPacket);
            };
            fuck_peer.OnRtpPacketReceived += (IPEndPoint, SDPMediaTypesEnum, RTPPacket) =>
            {
                Console.WriteLine("OnRtpPacketReceived IPEndPoint=====" + IPEndPoint);
                Console.WriteLine("OnRtpPacketReceived SDPMediaTypesEnum=====" + SDPMediaTypesEnum);
                Console.WriteLine("OnRtpPacketReceived RTPPacket=====" + RTPPacket);
            };
            fuck_peer.OnRtpEvent += (IPEndPoint, RTPEvent, RTPHeader) =>
            {
            };

            //mount track fuck_peer.AudioLocalTrack == null
            if (true)
            {
                var audioTrack = new MediaStreamTrack(
                    SDPMediaTypesEnum.audio, false,
                    new List<SDPMediaFormat> { new SDPMediaFormat(SDPMediaFormatsEnum.PCMU), },
                    MediaStreamStatusEnum.SendRecv);
                fuck_peer.addTrack(audioTrack);
            }

            //candicate 是如何生成的呢？浏览器 是自动的 那这边呢？
            // 我这边需要创建新的candidate 先绑定到自己 再传输给对方
            //我想发送candidate 但是为什么本地不生成呢 是因为加密问题 大概是先收到了别人的candidate才会生成自己的

            //当链接之后再次链接一次 就会变成 oniceconnectionstatechange = connected哦 然后就他妈掉了disconnected了
            fuck_peer.onconnectionstatechange += (state) => Fuck($"Peer connection state change to {state}.");
            fuck_peer.onnegotiationneeded += () => Fuck("onnegotiationneeded");
            fuck_peer.onsignalingstatechange += () => Fuck("onsignalingstatechange");
            fuck_peer.onicegatheringstatechange += (state) => Fuck("onicegatheringstatechange" + state);
            fuck_peer.onicecandidateerror += (candidate, info) => Fuck("onicecandidateerror" + candidate + "-----" + info);
            fuck_peer.oniceconnectionstatechange += (state) =>
            {
                Fuck($"ICE connection state change to {state}.");
                //fuck_peer.restartIce();
            };
            fuck_peer.onicecandidate += (_RTCIceCandidate) =>
            {
                fuck_peer.GetRtpChannel().Start();
                Fuck($"onicecandidate  fuck-me ");
            };


            var _createDataChannel = fuck_peer.createDataChannel("sendChannel", new RTCDataChannelInit());
            _createDataChannel.onmessage += (info) => { Fuck(info); };
        }

        async Task ExecuteLoadItemsCommand()
        {
            IsBusy = true;

            try
            {
                Items.Clear();
                var items = await DataStore.GetItemsAsync(true);
                foreach (var item in items)
                {
                    Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
            finally
            {
                IsBusy = false;
            }
        }

        private static void Fuck(string log)
        {
            Console.WriteLine($"[fuck] : {log} \r\n");
        }

        private static void AddConsoleLogger()
        {
            var loggerFactory = new LoggerFactory();
            var loggerConfig = new LoggerConfiguration()
                .Enrich.FromLogContext()
                .MinimumLevel.Is(Serilog.Events.LogEventLevel.Debug)
                //.WriteTo.Console()
                .WriteTo.Debug()
                .CreateLogger();
            loggerFactory.AddSerilog(loggerConfig);
            SIPSorcery.Sys.Log.LoggerFactory = loggerFactory;
        }
    }
}